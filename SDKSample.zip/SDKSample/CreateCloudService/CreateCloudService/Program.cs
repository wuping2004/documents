﻿using Microsoft.Azure.Management.ResourceManager;
//using Microsoft.Azure.Management.ResourceManager.Models;
using Microsoft.Azure.Management.Compute;
using Microsoft.Azure.Management.Compute.Models;
//using Microsoft.Azure.Management.Network;
//using Microsoft.Azure.Management.Network.Models;
using Microsoft.Azure.Management.Storage;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using System.IO;


namespace CreateCloudService
{
    public class Program: Utilities
    {
        //protected static string AdminUsername = "<username>";
        //protected static string AdminPassword = "<password>";
        
        static async Task Main(string[] args)
        {
            var creds = new LoginHelper();
            m_subId = "5102f0a2-xxxx-xxxx-xxxx-2834a4473453"; // subscription ID where the CSES is in
            m_ResourcesClient = new ResourceManagementClient(creds);
            //m_NrpClient = new NetworkManagementClient(creds);
            m_CrpClient = new ComputeManagementClient(creds);
            //m_SrpClient = new StorageManagementClient(creds);
            m_ResourcesClient.SubscriptionId = m_subId;
            //m_NrpClient.SubscriptionId = m_subId;
            m_CrpClient.SubscriptionId = m_subId;
            //m_SrpClient.SubscriptionId = m_subId;

            // Initialize variable names
            var csrgName = "CSESHTTP"; // name of resource group where the CSES is in
            var csName = "jerrycseshttp"; // name of CSES resource
            var kvrgName = "CSES"; // name of resource group where the KeyVault is in
            var kvName = "CSESKVault"; // name of KeyVault resource
            var kvsubid = m_subId; // subscription ID where KeyVault is in
            var keyvaulturl = "/subscriptions/" + kvsubid + "/resourceGroups/" + kvrgName + "/providers/Microsoft.KeyVault/vaults/" + kvName;
            var secretidentifier = "https://cseskvault.vault.azure.net/secrets/csescert/f22eafd302b54a2a9a1fa3ca4e4ece16"; // secret identifier URL of the certificate in KeyVault
            var filename = @"C:\Users\zhangjerry\Desktop\VisualStudioproject\CSESOneWebRoleHTTPS\bin\Release\app.publish\ServiceConfiguration.Cloud.cscfg"; // local path to the .cscfg file
            // the SAS token URL of .cspkg file
            var packageurl = "https://minalinsky.blob.core.windows.net/cses-https/CSESOneWebRoleHTTPS.cspkg?sp=r&st=2021-11-15T08:45:41Z&se=2021-12-14T16:45:41Z&spr=https&sv=2020-08-04&sr=b&sig=NOooNM5VbShc1g1WcKSvTdiHxxxxuDNaxxxxfcUdSBQ%3D";

            // Generate Cloud Service Object
            CloudService cses = m_CrpClient.CloudServices.Get(csrgName, csName);
            var prop = cses.Properties;

            // Get the Key Vault object and certificate object
            var keyvault = new Microsoft.Azure.Management.Compute.Models.SubResource(keyvaulturl);
            CloudServiceVaultCertificate certURL = new CloudServiceVaultCertificate(secretidentifier);

            // Add the certificate into OsProfile property.
            // Adding into existing configuration or create a new configuration will depend on whether the CSES is already with OsProfile property
            if (prop.OsProfile.Secrets.Count() == 0) // if OsProfile is empty
            {
                IList<CloudServiceVaultCertificate> certlist = new List<CloudServiceVaultCertificate>();
                certlist.Add(certURL);

                CloudServiceVaultSecretGroup csvsg = new CloudServiceVaultSecretGroup(keyvault, certlist);
                IList<CloudServiceVaultSecretGroup> csvsglist = new List<CloudServiceVaultSecretGroup>();
                csvsglist.Add(csvsg);

                prop.OsProfile = new CloudServiceOsProfile(csvsglist);
            }
            else // if OsProfile is not empty, which means there is original OsProfile setting
            {
                Boolean found = false;
                // Look for the setting of same Key Vault at first.
                foreach (var secret in prop.OsProfile.Secrets)
                {
                    if (secret.SourceVault.Id == keyvault.Id)
                    {
                        // Found the same KeyVault
                        found = true;

                        Boolean found2 = false;

                        // Check if the same certificate is already in the OsProfile
                        foreach(var c in secret.VaultCertificates)
                        {
                            if(c.CertificateUrl == secretidentifier)
                            {
                                found2 = true;
                            }
                        }

                        // Only when the new certificate is not found in the original OsProfile, we need to add it into setting
                        if(found2 == false)
                        {
                            secret.VaultCertificates.Add(certURL);
                        }

                        break;
                    }
                }

                // If the Key Vault is not found in the original setting, then we must add this Key Vault and related certificate setting
                if (found == false)
                {
                    IList<CloudServiceVaultCertificate> certlist = new List<CloudServiceVaultCertificate>();
                    certlist.Add(certURL);

                    CloudServiceVaultSecretGroup csvsg = new CloudServiceVaultSecretGroup(keyvault, certlist);
                    prop.OsProfile.Secrets.Add(csvsg);
                }
            }

            prop.PackageUrl = packageurl;
            prop.Configuration = File.ReadAllText(filename);

            UpdateCloudService(csrgName, csName, cses);

        }

    }
}
